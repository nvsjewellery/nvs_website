const express = require("express");
const router = express.Router();
const prisma = require("../lib/prisma");

/*
|--------------------------------------------------------------------------
| GET /api/cart
|--------------------------------------------------------------------------
*/

router.get("/", async (req, res) => {
  try {
    const userId = req.user.id;

    const cart = await prisma.cart.findMany({
      where: { userId },
      include: {
        product: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    return res.status(200).json({
      success: true,
      cart,
    });

  } catch (err) {

    console.error("GET Cart:", err);

    return res.status(500).json({
      success: false,
      message: "Failed to load cart",
    });

  }
});

/*
|--------------------------------------------------------------------------
| POST /api/cart
|--------------------------------------------------------------------------
*/

router.post("/", async (req, res) => {

  try {

    const userId = req.user.id;

    const { productId, qty = 1 } = req.body;

    if (!productId) {
      return res.status(400).json({
        success: false,
        message: "Product ID is required",
      });
    }

    const product = await prisma.product.findUnique({
      where: {
        id: productId,
      },
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      });
    }

    const existing = await prisma.cart.findUnique({
      where: {
        userId_productId: {
          userId,
          productId,
        },
      },
    });

    let cart;

    if (existing) {

      cart = await prisma.cart.update({
        where: {
          id: existing.id,
        },
        data: {
          qty: existing.qty + qty,
        },
        include: {
          product: true,
        },
      });

    } else {

      cart = await prisma.cart.create({
        data: {
          userId,
          productId,
          qty,
        },
        include: {
          product: true,
        },
      });

    }

    return res.status(200).json({
      success: true,
      cart,
    });

  } catch (err) {

    console.error("POST Cart:", err);

    return res.status(500).json({
      success: false,
      message: "Failed to add cart item",
    });

  }

});

/*
|--------------------------------------------------------------------------
| PUT /api/cart/:productId
|--------------------------------------------------------------------------
*/

router.put("/:productId", async (req, res) => {

  try {

    const userId = req.user.id;

    const { productId } = req.params;

    const { qty } = req.body;

    if (qty <= 0) {

      await prisma.cart.deleteMany({
        where: {
          userId,
          productId,
        },
      });

      return res.json({
        success: true,
      });

    }

    const cart = await prisma.cart.updateMany({
      where: {
        userId,
        productId,
      },
      data: {
        qty,
      },
    });

    return res.json({
      success: true,
      cart,
    });

  } catch (err) {

    console.error("UPDATE Cart:", err);

    return res.status(500).json({
      success: false,
      message: "Failed to update cart",
    });

  }

});

/*
|--------------------------------------------------------------------------
| DELETE /api/cart/:productId
|--------------------------------------------------------------------------
*/

router.delete("/:productId", async (req, res) => {

  try {

    const userId = req.user.id;

    const { productId } = req.params;

    await prisma.cart.deleteMany({
      where: {
        userId,
        productId,
      },
    });

    return res.status(200).json({
      success: true,
      message: "Removed from cart",
    });

  } catch (err) {

    console.error("DELETE Cart:", err);

    return res.status(500).json({
      success: false,
      message: "Failed to remove cart item",
    });

  }

});

module.exports = router;