const express = require("express");
const router = express.Router();
const prisma = require("../lib/prisma");

/*
|--------------------------------------------------------------------------
| GET /api/wishlist
|--------------------------------------------------------------------------
*/

router.get("/", async (req, res) => {
  try {
    const userId = req.user.id;

    const wishlist = await prisma.wishlist.findMany({
      where: { userId },
      include: {
        product: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    return res.status(200).json({
      success: true,
      wishlist,
    });
  } catch (err) {
    console.error("GET Wishlist:", err);

    return res.status(500).json({
      success: false,
      message: "Failed to load wishlist",
    });
  }
});

/*
|--------------------------------------------------------------------------
| POST /api/wishlist
|--------------------------------------------------------------------------
*/

router.post("/", async (req, res) => {
  try {
    const userId = req.user.id;
    const { productId } = req.body;

    if (!productId) {
      return res.status(400).json({
        success: false,
        message: "Product ID is required",
      });
    }

    const product = await prisma.product.findUnique({
      where: {
        id: productId,
      },
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found",
      });
    }

    const exists = await prisma.wishlist.findUnique({
      where: {
        userId_productId: {
          userId,
          productId,
        },
      },
    });

    if (exists) {
      return res.status(200).json({
        success: true,
        message: "Already in wishlist",
      });
    }

    const wishlist = await prisma.wishlist.create({
      data: {
        userId,
        productId,
      },
      include: {
        product: true,
      },
    });

    return res.status(201).json({
      success: true,
      wishlist,
    });

  } catch (err) {

    console.error("POST Wishlist:", err);

    return res.status(500).json({
      success: false,
      message: "Failed to add wishlist item",
    });

  }
});

/*
|--------------------------------------------------------------------------
| DELETE /api/wishlist/:productId
|--------------------------------------------------------------------------
*/

router.delete("/:productId", async (req, res) => {

  try {

    const userId = req.user.id;
    const { productId } = req.params;

    await prisma.wishlist.deleteMany({
      where: {
        userId,
        productId,
      },
    });

    return res.status(200).json({
      success: true,
      message: "Removed from wishlist",
    });

  } catch (err) {

    console.error("DELETE Wishlist:", err);

    return res.status(500).json({
      success: false,
      message: "Failed to remove wishlist item",
    });

  }

});

module.exports = router;